package com.example.instagram.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class instagramcontroller {
	@GetMapping("/post")
public String post(@RequestParam String username)
{
	return "Instagram post of "+username;
}
}
